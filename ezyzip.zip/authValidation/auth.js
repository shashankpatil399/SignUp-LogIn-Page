
const userDataValidate = (req, res, next) => {
    let errorMessage = "";
    if (!req.body.name) {
      errorMessage = "name is required";
    }

    // send error
    if (errorMessage) { 
      res.status(400).json({ success: false, errorMessage });
    }
  
    next();
  };

  module.exports = userDataValidate