const User = require("../models/userModel")
const  emplo = require("../models/emploModel")
const jwt = require('jsonwebtoken');
const mongoose = require("mongoose")
const bcrypt = require("bcrypt")
const multer = require ("multer")
const upload = multer ({ dest: "../upload/images" })



//CREATE TOKEN API
const login = async (req, res) => {
  
  try {
  const { email, password } = req.body;
  const user = await User.findOne({ email:email });
  if (!user) {
  return res.status(401).json({ error: 'Authentication failed' });
  }
  const passwordMatch = bcrypt.compare(password, user.password);
console.log("passwordMatch",passwordMatch)
  if (!passwordMatch) {
  return res.status(401).json({ error: 'Authentication failed' });
  }
  const token = jwt.sign({ userId: user._id }, 'your-secret-key', {
  expiresIn: '1h',
  });
  res.status(200).json({ token });
  } catch (error) {
  res.status(500).json({ error: 'Login failed' });
  }
  };
// addemplo
  const addEmplo = async(req,res)=>{
    console.log("req",req.body)
    const data = new emplo({
      userId  : req.body.userId,
      compnayname: req.body?.compnayname,
      companyemail: req.body?.companyemail
    
      
    })
    return res.status(200).json({
      status: 200,
      data
    });
  }



//reademplo
    // const readEmployee = async (req, res) => {
  
    //   fetchid=req.params.id
    //   const employee = await emplo.find({_id:fetchid});
    //   console.log(employee)
    //   res.send(employee);
    // }


//reademploanduser

    const readEmployeeAndUser =async(req,res) =>{
      const employee = await emplo.find().populate("userId");
      console.log(employee)
      res.send(employee);
    

    // const result = await data.save()
    // return res.status(200).json({
    //   status: 200,
    //   log

    }


//add user
const addUser = async(req,res) => {
  console.log("req",req.body)
  const data = new User({
    name :req.body?.name,
    email: req.body?.email,
    mobile: req.body?.mobile,
    father: req.body?.father,
    password: req.body?.password,
  });

   const result = await data.save()
   console.log("result",result)

   return res.status(200).json({
    status: 200,
    message : "User register",
    data : result
  });
 
}
   
//get item
const getItem = async(req,res)=>{
   try{
      
       const getAllUser = await User.find()
       console.log("getAllUser",getAllUser);
       res.send(getAllUser)
   }
   catch(err){
       console.log(err)
   }
}


//update Item
const updateItem =  async (req, res) => {
   const id  = req.params.id;
   const { name, email, age } = req.body;
 
   try {
     const updateData = await User.findByIdAndUpdate(id, { name, email, age }, { new: true });
     res.send(updateData);
   } catch (error) {
     console.error(error);
     res.status(500).send(error);
   }
 };



 //deleteItem
 const deleteItem = async (req, res) => {
   const { id } = req.params;
 
   try {
     const userrr = await User.findByIdAndDelete(id);
     res.send(userrr);
   } catch (error) {
     console.error(error);
     res.status(500).send(error);
   }
 };


 //getuser
 const getuser = async (req,res)=>{

  const userId  = req.userId


console.log("user id",userId)
const userID = await User.findById(userId)
res.send(userID)
console.log(userID);
 }
 

 //login
 const Login =async (req, res) => {
  try {
  const {email, password } = req.body;
  const user = await User.findOne({ email});
 
  if (!user) {
  return res.status(401).json({ error: 'Authentication failed' });
  }
  const passwordMatch = bcrypt.compare(password, user.password);
 

  if (!passwordMatch) {
  return res.status(401).json({ error: 'Authentication failed' });
  }
  const token = jwt.sign({ userId: user._id }, 'your-secret-key', {
  expiresIn: '1h',
  });
  res.status(200).json({ 
      status : 200 , 
      message : "User login!",
      data : user,
      token : token
   });
  } catch (error) {
  res.status(500).json({ error: 'Login failed' });
  }
  }

  module.exports={addUser,readEmployeeAndUser,Login};