const express = require("express");
const router = express.Router() 
const userController = require("../controller/userController")
const { body, validationResult } = require('express-validator');
const userDataValidate = require("../authValidation/auth");
const verifyToken = require("../middleware/authMiddleware")
const multer = require ("multer")
const path = require("path")
const User = require("../models/userModel")


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './upload/images')
    },
    filename: function (req, file, cb) {
    let ext = path.extname(file.originalname);
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    file.originalname = uniqueSuffix + ext
    cb(null,file.originalname);
    }
  })
  const upload = multer({ storage: storage })
// router.post("/addUser",[body ("name").trim().isEmpty().withMessage("name is require")],

// (req,res)=>{const error = validationResult(req);
//     if(!error.isEmpty())
//     return res.status(400).json({error: error.array()[0]})
// res.send(req.body);

// },userController.addUser)
router.post('/verify', verifyToken, (req, res) => {
    res.status(200).json({ message: 'Protected route accessed'}
)})

router.post ("/upload",upload.single("image"),async (req,res)=>{
    res.send("suces");

    const user = new User({
        email:req.body.email,
        password:req.body.password,
        image:req.file.originalname
    })
    await user.save()

    console.log(req.body)
    console.log(req.file)
});
// router.get("/getuser",verifyToken,userController.getuser);
router.post("/Login",userController.Login);
router.post("/addUser",userController.addUser);
// router.get("/get-all-user",userController.getItem);
// router.put("/update/:id",userController.updateItem);
// router.delete("/deleteUser/:id",userController.deleteItem);
// router.post("/addEmplo",userController.addEmplo)
// router.get( "/getemplo",userController.readEmployee)
// router.get( "/readEmployeeAndUser",userController.readEmployeeAndUser);

module.exports = router;